package com.isladragoncitos.item;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModItems;
import java.util.function.Supplier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Materiales de armadura del mod: la Placa Omega y la Corona de la Psique. */
public enum DragonArmorMaterial implements ArmorMaterial {
    OMEGA("omega", 70, new int[]{4, 9, 12, 4}, 30, SoundEvents.ARMOR_EQUIP_NETHERITE, 5.0F, 0.4F,
            () -> Ingredient.of(ModItems.VOID_CORE.get())),
    PSYCHE("psyche", 50, new int[]{5, 8, 10, 5}, 35, SoundEvents.ARMOR_EQUIP_GOLD, 3.0F, 0.1F,
            () -> Ingredient.of(ModItems.COSMIC_DUST.get()));

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final SoundEvent sound;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<Ingredient> repair;

    DragonArmorMaterial(String name, int durabilityMultiplier, int[] defense, int enchantability, SoundEvent sound,
                        float toughness, float knockbackResistance, Supplier<Ingredient> repair) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.sound = sound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repair = repair;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[type.ordinal()] * this.durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return this.defense[type.ordinal()];
    }

    @Override
    public int getEnchantmentValue() {
        return this.enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return this.sound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repair.get();
    }

    @Override
    public String getName() {
        return IslaDragoncitosMod.MODID + ":" + this.name;
    }

    @Override
    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }
}
