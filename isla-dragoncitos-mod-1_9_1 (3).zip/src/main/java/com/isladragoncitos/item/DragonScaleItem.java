package com.isladragoncitos.item;

import com.isladragoncitos.entity.DragoncitoEntity;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Escama de dragon. Cada color tiene un poder (con el eco de las leyendas de los cofres):
 * rosa cura, verde hace florecer la piedra, azul da aliento de mar y roja protege del fuego.
 * Con clic derecho sobre tu dragoncito domado le cambia el color.
 */
public class DragonScaleItem extends Item {
    private final int variant;

    public DragonScaleItem(int variant, Properties properties) {
        super(properties);
        this.variant = variant;
    }

    public int getVariant() {
        return this.variant;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (this.variant == 1) {
            return InteractionResultHolder.pass(stack);
        }
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }
        int mark = com.isladragoncitos.system.DraconicData.hasMark(player) ? 2 : 1;
        if (this.variant == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200 * mark, mark));
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200 * mark, mark - 1));
            List<DragoncitoEntity> dragons = level.getEntitiesOfClass(DragoncitoEntity.class,
                    player.getBoundingBox().inflate(12.0D), d -> d.isOwnedBy(player));
            for (DragoncitoEntity dragon : dragons) {
                dragon.heal(dragon.getMaxHealth());
                if (level instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(ParticleTypes.HEART, dragon.getX(), dragon.getY() + 0.7D, dragon.getZ(),
                            5, 0.3D, 0.2D, 0.3D, 0.0D);
                }
            }
        } else if (this.variant == 2) {
            player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 6000 * mark, 0));
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 6000 * mark, 0));
        } else {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000 * mark, 0));
            player.clearFire();
        }
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0D, player.getZ(),
                    12, 0.5D, 0.6D, 0.5D, 0.0D);
        }
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.success(stack);
    }

    /** La escama verde hace florecer la piedra y la tierra de alrededor. */
    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (this.variant != 1) {
            return InteractionResult.PASS;
        }
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        BlockPos center = context.getClickedPos();
        RandomSource random = level.getRandom();
        int changed = 0;
        for (BlockPos scan : BlockPos.betweenClosed(center.offset(-3, -2, -3), center.offset(3, 2, 3))) {
            BlockPos pos = scan.immutable();
            if (pos.distSqr(center) > 10.0D) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            BlockState result = null;
            if (state.is(Blocks.DIRT) || state.is(Blocks.COARSE_DIRT) || state.is(Blocks.PODZOL)) {
                result = Blocks.GRASS_BLOCK.defaultBlockState();
            } else if (state.is(Blocks.STONE) || state.is(Blocks.COBBLESTONE) || state.is(Blocks.ANDESITE)
                    || state.is(Blocks.TUFF) || state.is(Blocks.GRAVEL)) {
                result = Blocks.MOSS_BLOCK.defaultBlockState();
            }
            if (result == null) {
                continue;
            }
            level.setBlock(pos, result, 3);
            changed++;
            BlockPos above = pos.above();
            if (level.getBlockState(above).isAir() && random.nextInt(3) == 0) {
                int pick = random.nextInt(6);
                BlockState plant = pick < 2 ? Blocks.GRASS.defaultBlockState()
                        : (pick == 2 ? Blocks.FERN.defaultBlockState()
                        : (pick == 3 ? Blocks.DANDELION.defaultBlockState()
                        : (pick == 4 ? Blocks.AZURE_BLUET.defaultBlockState() : Blocks.PINK_TULIP.defaultBlockState())));
                level.setBlock(above, plant, 3);
            }
        }
        if (changed == 0) {
            return InteractionResult.PASS;
        }
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, center.getX() + 0.5D, center.getY() + 1.0D,
                    center.getZ() + 0.5D, 25, 1.5D, 0.5D, 1.5D, 0.0D);
        }
        level.playSound(null, center, SoundEvents.MOSS_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
        Player player = context.getPlayer();
        if (player == null || !player.getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        if (player != null) {
            player.getCooldowns().addCooldown(this, 20);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.scale." + this.variant)
                .withStyle(net.minecraft.ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.scale.recolor")
                .withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
    }
}
