package com.isladragoncitos.item;

import com.isladragoncitos.registry.ModItems;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

/** Hoz de Cronos: ralentiza el tiempo de lo que golpea. */
public class ChronosSickleItem extends SwordItem {
    private static final Tier TIER = new Tier() {
        @Override public int getUses() { return 3200; }
        @Override public float getSpeed() { return 9.0F; }
        @Override public float getAttackDamageBonus() { return 6.0F; }
        @Override public int getLevel() { return 4; }
        @Override public int getEnchantmentValue() { return 25; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.TIME_SHARD.get()); }
    };

    public ChronosSickleItem(Properties properties) {
        super(TIER, 3, -2.2F, properties.fireResistant());
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1));
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.chronos_sickle").withStyle(ChatFormatting.GRAY));
    }
}
