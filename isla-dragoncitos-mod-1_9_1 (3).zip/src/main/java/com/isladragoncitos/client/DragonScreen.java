package com.isladragoncitos.client;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.network.DragonMenuInfo;
import com.isladragoncitos.network.DragonRequestPacket;
import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.registry.ModEntities;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

/**
 * Menu del dragon antiguo: ver su estado, mejorarlo con puntos draconianos, darle ordenes y mandarlo a una isla.
 * Si el jugador tiene varios dragones, el menu tiene una pagina por cada uno (flechas de la cabecera o teclas izquierda/derecha).
 */
public class DragonScreen extends Screen {
    private static final int W = 330;
    private static final int H = 226;
    private static final int PREVIEW_W = 104;
    private static final int PREVIEW_H = 84;
    private static final String[] MODES = {"Seguirte", "Quieto", "Deambulando", "Explorando", "De viaje"};
    private static final int ISLANDS_PER_PAGE = 5;

    /** La pestana elegida se recuerda al volver a abrir el menu. */
    private static int lastTab = 0;

    private DragonMenuInfo info;
    private DragonTheme theme;
    private int tab = lastTab;
    private int islandPage = 0;
    private int x0;
    private int y0;

    private AncientDragonEntity preview;
    private int previewType = -1;

    private record Row(int y, String label, int level, int max, String costText) {}

    private final List<Row> rows = new ArrayList<>();

    public DragonScreen(DragonMenuInfo info) {
        super(Component.literal("Dragón"));
        this.info = info;
        this.theme = DragonTheme.of(info.type());
    }

    /** Llega informacion nueva del servidor (tras una mejora u orden): se redibuja sin cerrar el menu. */
    public void update(DragonMenuInfo newInfo) {
        this.info = newInfo;
        this.theme = DragonTheme.of(newInfo.type());
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.preview != null) {
            this.preview.tickCount++;
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModKeys.DRAGON_MENU.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        if (this.info.found() && this.info.count() > 1) {
            if (keyCode == GLFW.GLFW_KEY_LEFT) {
                this.changePage(-1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_RIGHT) {
                this.changePage(1);
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        this.x0 = (this.width - W) / 2;
        this.y0 = (this.height - H) / 2;
        this.rows.clear();
        this.ensurePreview();

        this.addRenderableWidget(new DragonButton(this.x0 + W - 68, this.y0 + H - 22, 58, 14, "Cerrar", this.theme,
                button -> this.onClose()));
        if (!this.info.found()) {
            return;
        }

        if (this.info.count() > 1) {
            DragonButton prev = new DragonButton(this.x0 + 6, this.y0 + 5, 16, 14, "<", this.theme,
                    button -> this.changePage(-1));
            prev.setTooltip(Tooltip.create(Component.literal("Dragón anterior")));
            DragonButton next = new DragonButton(this.x0 + W - 22, this.y0 + 5, 16, 14, ">", this.theme,
                    button -> this.changePage(1));
            next.setTooltip(Tooltip.create(Component.literal("Dragón siguiente")));
            this.addRenderableWidget(prev);
            this.addRenderableWidget(next);
        }

        String[] names = {"Mejoras", "Órdenes", "Viajes"};
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            DragonButton tabButton = new DragonButton(this.x0 + 122 + i * 68, this.y0 + 32, 64, 16, names[i], this.theme,
                    button -> {
                        this.tab = index;
                        lastTab = index;
                        this.rebuildWidgets();
                    });
            tabButton.selected = this.tab == i;
            this.addRenderableWidget(tabButton);
        }

        switch (this.tab) {
            case 0 -> this.buildUpgrades();
            case 1 -> this.buildOrders();
            default -> this.buildIslands();
        }
    }

    private void ensurePreview() {
        if (!this.info.found()) {
            this.preview = null;
            this.previewType = -1;
            return;
        }
        if (this.preview != null && this.previewType == this.info.type()) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        try {
            AncientDragonEntity entity = ModEntities.ANCIENT_DRAGON.get().create(minecraft.level);
            if (entity != null) {
                entity.setDragonType(this.info.type());
                this.preview = entity;
                this.previewType = this.info.type();
            }
        } catch (Exception ignored) {
            this.preview = null;
        }
    }

    private void buildUpgrades() {
        int rx = this.x0 + 122;
        int y = this.y0 + 56;
        this.statRow(rx, y, "fuerza", "Fuerza", this.info.strength(), AncientDragonEntity.MAX_STRENGTH, 2, "1 pto/nivel");
        this.statRow(rx, y + 27, "velocidad", "Velocidad", this.info.speed(), AncientDragonEntity.MAX_SPEED, 10, "5 ptos/nivel");
        this.statRow(rx, y + 54, "vida", "Vida", this.info.healthLvl(), AncientDragonEntity.MAX_HEALTH_LVL, 1, "0,5 ptos/nivel");
        this.statRow(rx, y + 81, "escamas", "Escamas protectoras", this.info.scales(), AncientDragonEntity.MAX_SCALES, 2,
                "1 pto/escama");

        int sy = y + 108;
        if (this.info.sharedLife()) {
            this.rows.add(new Row(sy, "Vida compartida", 1, 1, "activa"));
        } else {
            this.rows.add(new Row(sy, "Vida compartida", -1, 1, "100 ptos"));
            DragonButton buy = new DragonButton(rx, sy + 10, 198, 14, "Unir vidas (100 puntos)", this.theme,
                    button -> this.sendUpgrade("vida_compartida", 1));
            buy.active = this.info.halfPoints() >= 200;
            buy.setTooltip(Tooltip.create(Component.literal("Tu vida y la del dragón se suman y la comparten los dos."
                    + " Si uno muere, el otro también.")));
            this.addRenderableWidget(buy);
        }
    }

    private void statRow(int rx, int y, String stat, String label, int level, int max, int costHalf, String costText) {
        this.rows.add(new Row(y, label, level, max, costText));
        boolean canBuy = level < max && this.info.halfPoints() >= costHalf;
        int[] amounts = {1, 10, 1000};
        String[] texts = {"+1", "+10", "Máx"};
        int[] widths = {26, 28, 32};
        int bx = rx + 198 - (26 + 28 + 32 + 4);
        for (int i = 0; i < amounts.length; i++) {
            final int amount = amounts[i];
            DragonButton button = new DragonButton(bx, y + 10, widths[i], 14, texts[i], this.theme,
                    b -> this.sendUpgrade(stat, amount));
            button.active = canBuy;
            button.setTooltip(Tooltip.create(Component.literal(costText + (amount == 1000 ? " (sube todo lo que puedas pagar)" : ""))));
            this.addRenderableWidget(button);
            bx += widths[i] + 2;
        }
    }

    private void buildOrders() {
        int rx = this.x0 + 122;
        int y = this.y0 + 58;
        String[][] orders = {
                {"Seguir", "seguir", "Te sigue a cierta distancia", "0"},
                {"Quedarse", "quedarse", "Se queda donde está", "1"},
                {"Deambular aquí", "deambular", "Pasea en 32 bloques alrededor de ti", "2"},
                {"Explorar", "explorar", "Explora solo; muévete con las teclas para retomar el control", "3"},
                {"Isla cercana", "buscar", "Te lleva a la isla de dragoncitos más cercana", "-1"},
                {"Parar", "parar", "Cancela la orden actual", "-1"}
        };
        for (int i = 0; i < orders.length; i++) {
            final String order = orders[i][1];
            DragonButton button = new DragonButton(rx + (i % 2) * 101, y + (i / 2) * 26, 97, 22, orders[i][0], this.theme,
                    b -> ModNetwork.CHANNEL.sendToServer(new DragonRequestPacket(DragonRequestPacket.ORDER, order, 0)));
            button.selected = Integer.parseInt(orders[i][3]) == this.info.mode();
            button.setTooltip(Tooltip.create(Component.literal(orders[i][2])));
            this.addRenderableWidget(button);
        }
    }

    private void buildIslands() {
        int rx = this.x0 + 122;
        int y = this.y0 + 58;
        List<String> islands = this.info.islands();
        int start = this.islandPage * ISLANDS_PER_PAGE;
        if (start >= islands.size() && this.islandPage > 0) {
            this.islandPage = 0;
            start = 0;
        }
        for (int i = 0; i < ISLANDS_PER_PAGE && start + i < islands.size(); i++) {
            final String name = islands.get(start + i);
            DragonButton button = new DragonButton(rx, y + i * 24, 198, 20, name, this.theme,
                    b -> ModNetwork.CHANNEL.sendToServer(new DragonRequestPacket(DragonRequestPacket.GOTO, name, 0)));
            button.setTooltip(Tooltip.create(Component.literal("Vuelo automático a " + name)));
            this.addRenderableWidget(button);
        }
        if (islands.size() > ISLANDS_PER_PAGE) {
            DragonButton prev = new DragonButton(rx, y + 124, 97, 14, "<", this.theme, b -> {
                this.islandPage--;
                this.rebuildWidgets();
            });
            prev.active = this.islandPage > 0;
            final int nextStart = start + ISLANDS_PER_PAGE;
            DragonButton next = new DragonButton(rx + 101, y + 124, 97, 14, ">", this.theme, b -> {
                this.islandPage++;
                this.rebuildWidgets();
            });
            next.active = nextStart < islands.size();
            this.addRenderableWidget(prev);
            this.addRenderableWidget(next);
        }
    }

    /** Pasa a la pagina del dragon anterior (-1) o siguiente (+1); el servidor lo deja como dragon seleccionado. */
    private void changePage(int delta) {
        int count = this.info.count();
        if (count > 1) {
            ModNetwork.CHANNEL.sendToServer(new DragonRequestPacket(DragonRequestPacket.SELECT, "",
                    Math.floorMod(this.info.index() + delta, count)));
        }
    }

    private void sendUpgrade(String stat, int amount) {
        ModNetwork.CHANNEL.sendToServer(new DragonRequestPacket(DragonRequestPacket.UPGRADE, stat, amount));
    }

    // ------------------------------------------------------------------ dibujo

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        DragonTheme t = this.theme;
        int x0 = this.x0;
        int y0 = this.y0;

        // marco y fondo
        graphics.fill(x0 - 3, y0 - 3, x0 + W + 3, y0 + H + 3, DragonTheme.mix(t.dark(), t.accent(), 0.35F));
        graphics.fill(x0 - 2, y0 - 2, x0 + W + 2, y0 + H + 2, t.dark());
        graphics.renderOutline(x0 - 1, y0 - 1, W + 2, H + 2, t.accent());
        graphics.fillGradient(x0, y0, x0 + W, y0 + H, t.mid(), t.dark());

        // cabecera con hilera de escamas
        graphics.fillGradient(x0, y0, x0 + W, y0 + 25, DragonTheme.mix(t.mid(), t.accent(), 0.30F), t.mid());
        graphics.fill(x0, y0 + 25, x0 + W, y0 + 26, t.accent());
        for (int sx = x0 + 8; sx < x0 + W - 8; sx += 10) {
            graphics.fill(sx + 1, y0 + 27, sx + 4, y0 + 28, DragonTheme.mix(t.mid(), t.accent(), 0.55F));
            graphics.fill(sx + 2, y0 + 28, sx + 3, y0 + 29, DragonTheme.mix(t.mid(), t.accent(), 0.55F));
        }
        String title = this.info.found() ? t.name() : "Tu dragón";
        if (this.info.found() && this.info.count() > 1) {
            title += " (" + (this.info.index() + 1) + "/" + this.info.count() + ")";
        }
        graphics.drawCenteredString(this.font, Component.literal(title).withStyle(net.minecraft.ChatFormatting.BOLD),
                x0 + W / 2, y0 + 6, t.light());
        if (this.info.found() && this.info.count() > 1) {
            // un punto por dragon, del color de su elemento; el actual va resaltado
            int n = Math.min(this.info.count(), 36);
            int dx = x0 + W / 2 - (n * 8 - 4) / 2;
            for (int i = 0; i < n; i++) {
                int color = DragonTheme.of(this.info.types().get(i)).accent();
                boolean current = i == this.info.index();
                graphics.fill(dx + i * 8, y0 + 16, dx + i * 8 + 4, y0 + 20, current ? color : DragonTheme.mix(color, t.dark(), 0.6F));
                if (current) {
                    graphics.renderOutline(dx + i * 8 - 1, y0 + 15, 6, 6, t.light());
                }
            }
        }

        if (!this.info.found()) {
            int y = y0 + 80;
            for (FormattedCharSequence line : this.font.split(FormattedText.of(this.info.message()), W - 40)) {
                graphics.drawCenteredString(this.font, line, x0 + W / 2, y, 0xFFE0E0E0);
                y += 12;
            }
            super.render(graphics, mouseX, mouseY, partialTick);
            return;
        }

        this.renderLeft(graphics, mouseX, mouseY);
        this.renderRight(graphics);

        // mensaje del ultimo resultado
        int my = y0 + H - 24;
        for (FormattedCharSequence line : this.font.split(FormattedText.of(this.info.message()), W - 90)) {
            graphics.drawString(this.font, line, x0 + 10, my, 0xFFE9E9E9, false);
            my += 10;
            if (my > y0 + H - 6) {
                break;
            }
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void renderLeft(GuiGraphics graphics, int mouseX, int mouseY) {
        DragonTheme t = this.theme;
        int px = this.x0 + 10;
        int py = this.y0 + 32;
        graphics.fillGradient(px, py, px + PREVIEW_W, py + PREVIEW_H, DragonTheme.mix(t.dark(), t.accent(), 0.30F), t.dark());
        graphics.renderOutline(px, py, PREVIEW_W, PREVIEW_H, t.accent());
        if (this.preview != null) {
            graphics.enableScissor(px + 1, py + 1, px + PREVIEW_W - 1, py + PREVIEW_H - 1);
            try {
                InventoryScreen.renderEntityInInventoryFollowsMouse(graphics, px + PREVIEW_W / 2, py + PREVIEW_H - 12, 28,
                        (float) (px + PREVIEW_W / 2) - mouseX, (float) (py + PREVIEW_H / 2 - 20) - mouseY, this.preview);
            } catch (Exception ignored) {
                this.preview = null;
            }
            graphics.disableScissor();
        }

        int y = py + PREVIEW_H + 8;
        graphics.drawString(this.font, "Tamaño: " + String.format("%.1f", this.info.scale()), px, y, t.light(), false);
        this.bar(graphics, px, y + 10, PREVIEW_W, 5, (float) this.info.food() / AncientDragonEntity.FOOD_MAX, 0xFFE8B53A);
        graphics.drawString(this.font, "Vida: " + this.info.health() + "/" + this.info.maxHealth(), px, y + 19, t.light(), false);
        this.bar(graphics, px, y + 29, PREVIEW_W, 5,
                this.info.maxHealth() <= 0 ? 0F : (float) this.info.health() / this.info.maxHealth(), 0xFFD9453B);
        graphics.drawString(this.font, "Puntos: §6" + points(this.info.halfPoints()), px, y + 40, 0xFFFFFFFF, false);
        graphics.drawString(this.font, "Islas halladas: " + this.info.islandsFound(), px, y + 51, 0xFFC8C8C8, false);
        if (this.info.mark()) {
            graphics.drawString(this.font, "Marca del Jinete", px, y + 62, 0xFFFFD866, false);
        }
    }

    private void renderRight(GuiGraphics graphics) {
        DragonTheme t = this.theme;
        int rx = this.x0 + 122;
        if (this.tab == 0) {
            for (Row row : this.rows) {
                String level = row.level() < 0 ? "no" : (row.max() == 1 ? row.costText() : row.level() + "/" + row.max());
                graphics.drawString(this.font, row.label(), rx, row.y(), t.light(), false);
                String right = row.max() == 1 ? "" : row.costText();
                graphics.drawString(this.font, right, rx + 198 - this.font.width(right), row.y(), 0xFF9A9AA0, false);
                if (row.max() > 1) {
                    this.bar(graphics, rx, row.y() + 13, 198 - 92 - 4, 8, (float) row.level() / row.max(), t.accent());
                    graphics.drawString(this.font, level, rx + 3, row.y() + 14, 0xFFFFFFFF, true);
                } else if (row.level() >= 0) {
                    graphics.drawString(this.font, "§aactiva", rx + 198 - this.font.width("activa"), row.y(), 0xFFFFFFFF, false);
                }
            }
        } else if (this.tab == 1) {
            int mode = Math.max(0, Math.min(MODES.length - 1, this.info.mode()));
            graphics.drawString(this.font, "Orden actual: §f" + MODES[mode], rx, this.y0 + 146, t.light(), false);
        } else if (this.info.islands().isEmpty()) {
            int y = this.y0 + 62;
            for (FormattedCharSequence line : this.font.split(FormattedText.of(
                    "Aún no conoces ninguna isla. Reclama una tocando su estatua del dragón y podrás mandarlo hacia ella."), 198)) {
                graphics.drawString(this.font, line, rx, y, 0xFFC8C8C8, false);
                y += 10;
            }
        }
    }

    private void bar(GuiGraphics graphics, int x, int y, int w, int h, float fraction, int color) {
        graphics.fill(x, y, x + w, y + h, 0xFF0B0B0F);
        int filled = Math.round((w - 2) * Math.max(0F, Math.min(1F, fraction)));
        if (filled > 0) {
            graphics.fill(x + 1, y + 1, x + 1 + filled, y + h - 1, color);
            graphics.fill(x + 1, y + 1, x + 1 + filled, y + 2, DragonTheme.mix(color, 0xFFFFFFFF, 0.35F));
        }
        graphics.renderOutline(x, y, w, h, this.theme.accent());
    }

    private static String points(int halfPoints) {
        return halfPoints % 2 == 0 ? String.valueOf(halfPoints / 2) : (halfPoints / 2) + ",5";
    }
}
