package com.isladragoncitos.client;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;
import software.bernie.geckolib.core.object.Color;

/** Dibuja al dragon antiguo con el modelo 3D de GeckoLib; lava, rayos, cristales y ojos brillan en la oscuridad. */
public class AncientDragonRenderer extends GeoEntityRenderer<AncientDragonEntity> {
    /**
     * Los modelos nuevos miden unos 15 bloques de largo a escala 1. Este factor los lleva al mismo tamano
     * que el dragon anterior para que la hitbox, la montura y la camara sigan encajando. Subelo o bajalo
     * si los quieres mas grandes o mas pequenos.
     */
    public static final float MODEL_SCALE = 0.45F;

    /** El dragon de hielo es mas largo y de mas envergadura que los demas: este factor lo deja a un tamano parecido. */
    public static final float ICE_MODEL_SCALE = 0.8F;

    /** El dragon de tormenta (con su corona de cuernos) es algo mas imponente que los demas. */
    public static final float STORM_MODEL_SCALE = 1.12F;

    /** La serpiente celeste mide unos 33 bloques a escala 1 (es muy larga y fina): este factor la deja en ~10 bloques. */
    public static final float SKY_MODEL_SCALE = 0.67F;

    public AncientDragonRenderer(EntityRendererProvider.Context context) {
        super(context, new AncientDragonGeoModel());
        // usa X_dragon_glowmask.png junto a la textura
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    /** Montando un dragon grande en primera persona no se dibuja su cuerpo: la camara queda siempre despejada. */
    @Override
    public void render(AncientDragonEntity dragon, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.options.getCameraType().isFirstPerson() && minecraft.player != null
                && dragon.hasPassenger(minecraft.player) && dragon.getVisualScale() >= 2.5F) {
            return;
        }
        super.render(dragon, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    /** Las especies se tinen con el color de su elemento (algo suavizado para que no pierda detalle). */
    @Override
    public Color getRenderColor(AncientDragonEntity dragon, float partialTick, int packedLight) {
        var species = dragon.getSpecies();
        if (species == null) {
            return super.getRenderColor(dragon, partialTick, packedLight);
        }
        int tint = species.tint();
        int r = 255 - (int) ((255 - ((tint >> 16) & 0xFF)) * 0.75F);
        int g = 255 - (int) ((255 - ((tint >> 8) & 0xFF)) * 0.75F);
        int b = 255 - (int) ((255 - (tint & 0xFF)) * 0.75F);
        return Color.ofRGB(r, g, b);
    }

    @Override
    public void scaleModelForRender(float widthScale, float heightScale, PoseStack poseStack, AncientDragonEntity dragon,
                                    BakedGeoModel model, boolean isReRender, float partialTick, int packedLight,
                                    int packedOverlay) {
        float typeScale = dragon.getDragonType() == 1 ? ICE_MODEL_SCALE : (dragon.getDragonType() == 2 ? STORM_MODEL_SCALE
                : (dragon.getDragonType() == 4 ? SKY_MODEL_SCALE : 1.0F));
        float scale = dragon.getVisualScale() * MODEL_SCALE * typeScale;
        this.shadowRadius = 1.6F * scale;
        super.scaleModelForRender(widthScale * scale, heightScale * scale, poseStack, dragon, model, isReRender,
                partialTick, packedLight, packedOverlay);
    }
}
