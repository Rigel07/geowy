package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.network.AbilityPacket;
import com.isladragoncitos.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Teclas de las habilidades draconianas: R lanza la seleccionada, V cambia de habilidad. */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientAbilityEvents {
    private ClientAbilityEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || Minecraft.getInstance().player == null) {
            return;
        }
        while (ModKeys.ABILITY_CAST.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityPacket.CAST));
        }
        while (ModKeys.ABILITY_CYCLE.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityPacket.CYCLE));
        }
    }
}
