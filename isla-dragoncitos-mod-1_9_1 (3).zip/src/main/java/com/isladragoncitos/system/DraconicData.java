package com.isladragoncitos.system;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.worldgen.RiderLore;
import java.util.*;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.structure.StructureStart;

public final class DraconicData {
    public static final UUID SHARED_UUID = UUID.fromString("5d6c0888-9356-470f-8988-7cb74c2ac169");
    public static final String SHARED_PREFIX = "isladragoncitos_shared_";

    private static final String ROOT = "PlayerPersisted";
    private static final String KEY = "isladragoncitos";

    private static boolean linking;

    private DraconicData() {}

    private static CompoundTag data(Player player) {
        CompoundTag forge = player.getPersistentData();
        if (!forge.contains(ROOT)) {
            forge.put(ROOT, new CompoundTag());
        }
        CompoundTag persisted = forge.getCompound(ROOT);
        if (!persisted.contains(KEY)) {
            persisted.put(KEY, new CompoundTag());
        }
        return persisted.getCompound(KEY);
    }

    public static int getHalfPoints(Player player) {
        return data(player).getInt("HalfPoints");
    }

    public static void addHalfPoints(Player player, int amount) {
        CompoundTag tag = data(player);
        tag.putInt("HalfPoints", Math.max(0, tag.getInt("HalfPoints") + amount));
    }

    public static String formatPoints(int halfPoints) {
        return halfPoints % 2 == 0 ? String.valueOf(halfPoints / 2) : (halfPoints / 2) + ",5";
    }

    public static int getMarkLevel(Player player) {
        return data(player).getInt("MarkLevel");
    }

    public static void setMarkLevel(Player player, int level) {
        data(player).putInt("MarkLevel", level);
    }

    // ------------------------------------------------------------- habilidades draconianas

    public static boolean hasAbility(Player player, String abilityId) {
        return data(player).getBoolean("Ability_" + abilityId);
    }

    /** Desbloquea una habilidad; devuelve false si ya la tenia. */
    public static boolean unlockAbility(Player player, String abilityId) {
        CompoundTag tag = data(player);
        if (tag.getBoolean("Ability_" + abilityId)) {
            return false;
        }
        tag.putBoolean("Ability_" + abilityId, true);
        ListTag list = tag.getList("AbilityList", Tag.TAG_STRING);
        list.add(net.minecraft.nbt.StringTag.valueOf(abilityId));
        tag.put("AbilityList", list);
        if (tag.getString("AbilitySel").isEmpty()) {
            tag.putString("AbilitySel", abilityId);
        }
        return true;
    }

    public static List<String> getUnlockedAbilities(Player player) {
        List<String> abilities = new ArrayList<>();
        ListTag list = data(player).getList("AbilityList", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            abilities.add(list.getString(i));
        }
        return abilities;
    }

    public static void selectAbility(Player player, String abilityId) {
        data(player).putString("AbilitySel", abilityId);
    }

    public static String getSelectedAbility(Player player) {
        return data(player).getString("AbilitySel");
    }

    /** Pasa a la siguiente habilidad desbloqueada y devuelve su id (o "" si no hay ninguna). */
    public static String cycleAbility(Player player) {
        List<String> unlocked = getUnlockedAbilities(player);
        if (unlocked.isEmpty()) {
            return "";
        }
        int index = unlocked.indexOf(getSelectedAbility(player));
        String next = unlocked.get((index + 1) % unlocked.size());
        data(player).putString("AbilitySel", next);
        return next;
    }

    public static long getCooldownUntil(Player player, String abilityId) {
        return data(player).getLong("Cd_" + abilityId);
    }

    public static void setCooldownUntil(Player player, String abilityId, long gameTime) {
        data(player).putLong("Cd_" + abilityId, gameTime);
    }

    // ------------------------------------------------------------- codice (especies descubiertas)

    public static void discoverSpecies(Player player, String speciesId) {
        CompoundTag tag = data(player);
        ListTag list = tag.getList("Species", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            if (list.getString(i).equals(speciesId)) {
                return;
            }
        }
        list.add(net.minecraft.nbt.StringTag.valueOf(speciesId));
        tag.put("Species", list);
    }

    public static Set<String> getDiscoveredSpecies(Player player) {
        Set<String> found = new LinkedHashSet<>();
        ListTag list = data(player).getList("Species", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            found.add(list.getString(i));
        }
        return found;
    }

    // ------------------------------------------------------------- marca, islas, logros

    /** Marca del Jinete (nivel 1 o superior). */
    public static boolean hasMark(Player player) {
        return getMarkLevel(player) >= 1;
    }

    public static int islandsFound(Player player) {
        return data(player).getLongArray("IslandsSeen").length;
    }

    /** Da un logro del mod (isladragoncitos:id) si existe y aun no lo tiene. */
    public static void grant(ServerPlayer player, String id) {
        Advancement advancement = player.server.getAdvancements().getAdvancement(new ResourceLocation(IslaDragoncitosMod.MODID, id));
        if (advancement == null) {
            return;
        }
        for (String criterion : player.getAdvancements().getOrStartProgress(advancement).getRemainingCriteria()) {
            player.getAdvancements().award(advancement, criterion);
        }
    }

    /** Descubre islas y ruinas al pisarlas: +10 puntos draconianos por isla nueva. */
    private static void discover(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Registry<Structure> structures = level.registryAccess().registryOrThrow(Registries.STRUCTURE);
        BlockPos pos = player.blockPosition();
        Structure isla = structures.get(new ResourceLocation(IslaDragoncitosMod.MODID, "isla"));
        if (isla != null) {
            StructureStart start = level.structureManager().getStructureAt(pos, isla);
            if (start.isValid()) {
                long key = start.getChunkPos().toLong();
                CompoundTag tag = data(player);
                long[] seen = tag.getLongArray("IslandsSeen");
                boolean known = false;
                for (long value : seen) {
                    if (value == key) {
                        known = true;
                        break;
                    }
                }
                if (!known) {
                    long[] grown = java.util.Arrays.copyOf(seen, seen.length + 1);
                    grown[seen.length] = key;
                    tag.putLongArray("IslandsSeen", grown);
                    addHalfPoints(player, 20);
                    player.displayClientMessage(Component.literal("\u00a7bIsla descubierta: \u00a7e+10 puntos draconianos"), true);
                    grant(player, "island_found");
                    if (grown.length >= 10) grant(player, "islands_10");
                    if (grown.length >= 50) grant(player, "islands_50");
                }
            }
        }
        for (String ruin : new String[]{"rider_watch", "rider_graveyard", "rider_circle", "rider_sea", "life_tree"}) {
            Structure structure = structures.get(new ResourceLocation(IslaDragoncitosMod.MODID, ruin));
            if (structure != null && level.structureManager().getStructureAt(pos, structure).isValid()) {
                grant(player, "ruins_found");
            }
        }
    }

    // ------------------------------------------------------------- dragon activo y mejoras

    @Nullable
    public static AncientDragonEntity findDragon(ServerPlayer player) {
        CompoundTag tag = data(player);
        if (tag.hasUUID("Dragon")) {
            AncientDragonEntity active = lookup(player, tag.getUUID("Dragon"));
            if (active != null) {
                return active;
            }
        }
        List<AncientDragonEntity> all = findDragons(player);
        return all.isEmpty() ? null : all.get(0);
    }

    public static void selectDragon(ServerPlayer player, AncientDragonEntity dragon) {
        data(player).putUUID("Dragon", dragon.getUUID());
    }

    /** Gasta puntos draconianos en mejorar al dragon. Devuelve el mensaje para el jugador. */
    public static String upgrade(ServerPlayer player, AncientDragonEntity dragon, String stat, int levels) {
        int half = getHalfPoints(player);
        if (stat.equals("vida_compartida")) {
            if (dragon.hasSharedLife()) {
                return "\u00a7eTu vida ya est\u00e1 unida a la de tu drag\u00f3n.";
            }
            if (half < 200) {
                return "\u00a7cNecesitas 100 puntos exactos para unir las vidas (tienes " + formatPoints(half) + ").";
            }
            addHalfPoints(player, -200);
            dragon.setSharedLife(true);
            dragon.setHealth(dragon.getMaxHealth());
            grant(player, "shared_life");
            return "\u00a7a\u00a1Vuestras vidas ahora son una sola!";
        }
        int current;
        int max;
        int cost;
        switch (stat) {
            case "fuerza" -> { current = dragon.getStrengthLvl(); max = AncientDragonEntity.MAX_STRENGTH; cost = 2; }
            case "velocidad" -> { current = dragon.getSpeedLvl(); max = AncientDragonEntity.MAX_SPEED; cost = 10; }
            case "vida" -> { current = dragon.getHealthLvl(); max = AncientDragonEntity.MAX_HEALTH_LVL; cost = 1; }
            case "escamas" -> { current = dragon.getScales(); max = AncientDragonEntity.MAX_SCALES; cost = 2; }
            default -> { return "\u00a7cMejora desconocida: " + stat; }
        }
        int room = max - current;
        if (room <= 0) {
            return "\u00a7eYa est\u00e1 al m\u00e1ximo.";
        }
        int affordable = half / cost;
        int amount = Math.min(Math.min(levels, room), affordable);
        if (amount <= 0) {
            return "\u00a7cNo tienes puntos suficientes (cada nivel cuesta " + formatPoints(cost) + ").";
        }
        addHalfPoints(player, -amount * cost);
        switch (stat) {
            case "fuerza" -> dragon.setStrengthLvl(current + amount);
            case "velocidad" -> dragon.setSpeedLvl(current + amount);
            case "vida" -> dragon.setHealthLvl(current + amount);
            default -> dragon.setScales(current + amount);
        }
        dragon.refreshStats();
        return "\u00a7a" + stat + " +" + amount + " (" + (current + amount) + "/" + max + ")  \u00a77puntos: " + formatPoints(getHalfPoints(player));
    }

    public static void setActiveDragon(Player player, AncientDragonEntity dragon) {
        CompoundTag tag = data(player);
        List<UUID> ids = ownedIds(tag);
        if (!ids.contains(dragon.getUUID())) {
            ids.add(dragon.getUUID());
        }
        saveIds(tag, ids);
        tag.putUUID("Dragon", dragon.getUUID());
    }

    private static List<UUID> ownedIds(CompoundTag tag) {
        List<UUID> ids = new ArrayList<>();
        ListTag list = tag.getList("Dragons", Tag.TAG_INT_ARRAY);
        for (int i = 0; i < list.size(); i++) {
            UUID id = NbtUtils.loadUUID(list.get(i));
            if (!ids.contains(id)) ids.add(id);
        }
        if (tag.hasUUID("Dragon") && !ids.contains(tag.getUUID("Dragon"))) {
            ids.add(tag.getUUID("Dragon"));
        }
        return ids;
    }

    private static void saveIds(CompoundTag tag, List<UUID> ids) {
        ListTag list = new ListTag();
        for (UUID id : ids) list.add(NbtUtils.createUUID(id));
        tag.put("Dragons", list);
    }

    @Nullable
    public static AncientDragonEntity findSharedDragon(ServerPlayer player) {
        for (AncientDragonEntity dragon : findDragons(player)) {
            if (dragon.hasSharedLife()) return dragon;
        }
        return null;
    }

    public static List<AncientDragonEntity> findDragons(ServerPlayer player) {
        List<AncientDragonEntity> found = new ArrayList<>();
        for (UUID id : ownedIds(data(player))) {
            AncientDragonEntity dragon = lookup(player, id);
            if (dragon != null) found.add(dragon);
        }
        return found;
    }

    @Nullable
    private static AncientDragonEntity lookup(ServerPlayer player, UUID id) {
        for (ServerLevel level : player.server.getAllLevels()) {
            Entity entity = level.getEntity(id);
            if (entity instanceof AncientDragonEntity dragon && dragon.isAlive() && player.getUUID().equals(dragon.getOwnerUUID())) {
                return dragon;
            }
        }
        return null;
    }

    public static void onHatch(ServerPlayer player, UUID dragonId, int type) {
        CompoundTag tag = data(player);
        int mask = tag.getInt("Hatched") | (1 << type);
        tag.putInt("Hatched", mask);
        if (getMarkLevel(player) < 1) {
            setMarkLevel(player, 1);
            player.displayClientMessage(Component.literal("§6§lMarca del Jinete Nivel 1§r §eha despertado en ti: ventajas duplicadas."), false);
            player.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(), 60, 0.6D, 1.0D, 0.6D, 0.4D);
        }
    }

    public static void tickPlayer(ServerPlayer player) {
        if (player.tickCount % 10 == 0) {
            sharedLife(player);
        }
        if (player.tickCount % 60 == 0) {
            discover(player);
        }
    }

    private static void sharedLife(ServerPlayer player) {
        AttributeInstance maxHp = player.getAttribute(Attributes.MAX_HEALTH);
        if (maxHp == null) return;
        AttributeModifier existing = maxHp.getModifier(SHARED_UUID);
        AncientDragonEntity dragon = findSharedDragon(player);
        if (dragon != null && dragon.level() == player.level() && player.isAlive()) {
            double multiplier = getMarkLevel(player) >= 2 ? 2.0 : 1.0;
            double bonus = dragon.getMaxHealth() * multiplier;
            String name = SHARED_PREFIX + dragon.getDragonType();
            if (existing == null || existing.getAmount() != bonus) {
                if (existing != null) maxHp.removeModifier(SHARED_UUID);
                maxHp.addPermanentModifier(new AttributeModifier(SHARED_UUID, name, bonus, AttributeModifier.Operation.ADDITION));
            }
        } else if (existing != null) {
            maxHp.removeModifier(SHARED_UUID);
        }
    }

    public static void onDragonDied(AncientDragonEntity dragon) {
        if (!(dragon.getOwner() instanceof ServerPlayer owner)) return;
        CompoundTag tag = data(owner);
        List<UUID> ids = ownedIds(tag);
        ids.remove(dragon.getUUID());
        saveIds(tag, ids);
        if (tag.getInt("MarkLevel") > 0 && ids.isEmpty()) {
            tag.putInt("MarkLevel", 0);
            owner.displayClientMessage(Component.literal("§7La Marca del Jinete se ha desvanecido."), false);
        }
        if (dragon.hasSharedLife() && !linking) {
            linking = true;
            try { owner.kill(); } finally { linking = false; }
        }
    }

    public static void onPlayerDied(ServerPlayer player) {
        if (linking) return;
        AncientDragonEntity dragon = findSharedDragon(player);
        if (dragon != null) {
            linking = true;
            try { dragon.kill(); } finally { linking = false; }
        }
    }
}
