package com.isladragoncitos.network;

import com.isladragoncitos.client.ClientHooks;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: abre el menu del dragon (o lo refresca si ya esta abierto). */
public record DragonMenuPacket(DragonMenuInfo info) {

    public static void encode(DragonMenuPacket packet, FriendlyByteBuf buf) {
        packet.info().write(buf);
    }

    public static DragonMenuPacket decode(FriendlyByteBuf buf) {
        return new DragonMenuPacket(DragonMenuInfo.read(buf));
    }

    public static void handle(DragonMenuPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openDragonScreen(packet.info())));
        context.get().setPacketHandled(true);
    }
}
