package com.isladragoncitos.network;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.FriendlyByteBuf;

/** Servidor -> cliente: todo lo que muestra el menu del dragon (niveles, puntos, orden actual, islas conocidas). */
public record DragonMenuInfo(boolean found, int type, float scale, int food, int health, int maxHealth, int halfPoints,
                             int islandsFound, boolean mark, int strength, int speed, int healthLvl, int scales,
                             boolean sharedLife, int mode, List<String> islands, String message, int index, List<Integer> types) {

    public static DragonMenuInfo none(String message) {
        return new DragonMenuInfo(false, 0, 0.55F, 0, 0, 0, 0, 0, false, 0, 0, 0, 0, false, 0, List.of(), message, 0, List.of());
    }

    /** Cuantos dragones tiene el jugador (una pagina del menu por cada uno). */
    public int count() {
        return this.types.size();
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeBoolean(this.found);
        buf.writeVarInt(this.type);
        buf.writeFloat(this.scale);
        buf.writeVarInt(this.food);
        buf.writeVarInt(this.health);
        buf.writeVarInt(this.maxHealth);
        buf.writeVarInt(this.halfPoints);
        buf.writeVarInt(this.islandsFound);
        buf.writeBoolean(this.mark);
        buf.writeVarInt(this.strength);
        buf.writeVarInt(this.speed);
        buf.writeVarInt(this.healthLvl);
        buf.writeVarInt(this.scales);
        buf.writeBoolean(this.sharedLife);
        buf.writeVarInt(this.mode);
        buf.writeVarInt(this.islands.size());
        for (String island : this.islands) {
            buf.writeUtf(island, 64);
        }
        buf.writeUtf(this.message, 300);
        buf.writeVarInt(this.index);
        buf.writeVarInt(this.types.size());
        for (int dragonType : this.types) {
            buf.writeVarInt(dragonType);
        }
    }

    public static DragonMenuInfo read(FriendlyByteBuf buf) {
        boolean found = buf.readBoolean();
        int type = buf.readVarInt();
        float scale = buf.readFloat();
        int food = buf.readVarInt();
        int health = buf.readVarInt();
        int maxHealth = buf.readVarInt();
        int halfPoints = buf.readVarInt();
        int islandsFound = buf.readVarInt();
        boolean mark = buf.readBoolean();
        int strength = buf.readVarInt();
        int speed = buf.readVarInt();
        int healthLvl = buf.readVarInt();
        int scales = buf.readVarInt();
        boolean shared = buf.readBoolean();
        int mode = buf.readVarInt();
        int count = buf.readVarInt();
        List<String> islands = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            islands.add(buf.readUtf(64));
        }
        String message = buf.readUtf(300);
        int index = buf.readVarInt();
        int typeCount = buf.readVarInt();
        List<Integer> types = new ArrayList<>();
        for (int i = 0; i < typeCount; i++) {
            types.add(buf.readVarInt());
        }
        return new DragonMenuInfo(found, type, scale, food, health, maxHealth, halfPoints, islandsFound, mark, strength,
                speed, healthLvl, scales, shared, mode, islands, message, index, types);
    }
}
