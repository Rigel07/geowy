package com.isladragoncitos.entity;

import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.item.DraconicManuscriptItem;
import com.isladragoncitos.item.DragonScaleItem;
import com.isladragoncitos.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Adorador de los dragones: habitante pacifico de castillos, santuarios y aldeas. Reverencia a los jinetes:
 * a cambio de una escama de dragon da esencia draconiana y, a veces, un manuscrito con una habilidad.
 */
public class DragonWorshipperEntity extends PathfinderMob {
    private static final int LINES = 6;

    public DragonWorshipperEntity(EntityType<? extends DragonWorshipperEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Monster.class, 10.0F, 1.0D, 1.3D));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (stack.getItem() instanceof DragonScaleItem) {
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            this.spawnAtLocation(new ItemStack(ModItems.DRAGON_ESSENCE.get()));
            if (this.random.nextFloat() < 0.22F) {
                var ids = DraconicAbilities.ids();
                this.spawnAtLocation(DraconicManuscriptItem.of(ids.get(this.random.nextInt(ids.size()))));
                player.displayClientMessage(Component.translatable("entity.isladragoncitos.worshipper.manuscript"), true);
            } else {
                player.displayClientMessage(Component.translatable("entity.isladragoncitos.worshipper.thanks"), true);
            }
            this.level().playSound(null, this.blockPosition(), SoundEvents.VILLAGER_YES, SoundSource.NEUTRAL, 1.0F, 1.0F);
            return InteractionResult.CONSUME;
        }
        player.displayClientMessage(Component.translatable("entity.isladragoncitos.worshipper.line." + (1 + this.random.nextInt(LINES))), false);
        this.level().playSound(null, this.blockPosition(), SoundEvents.VILLAGER_AMBIENT, SoundSource.NEUTRAL, 1.0F, 1.0F);
        return InteractionResult.CONSUME;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // los dragones los protegen: si un jinete los hiere, no pasa nada grave
        return super.hurt(source, amount);
    }
}
