package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.AncientEggBlock;
import com.isladragoncitos.block.IslandStatueBlock;
import com.isladragoncitos.block.WorldTreeLeavesBlock;
import com.isladragoncitos.block.LifeTreeHeartBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, IslaDragoncitosMod.MODID);

    /** Estatua de teletransporte: indestructible, brilla suavemente. */
    public static final RegistryObject<Block> DRAGON_STATUE = BLOCKS.register("dragon_statue",
            () -> new IslandStatueBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 8)
                    .noOcclusion()
                    .pushReaction(PushReaction.BLOCK)));

    public static final RegistryObject<Block> PINK_SCALE_BLOCK = scaleBlock("pink_scale_block", MapColor.COLOR_PINK);
    public static final RegistryObject<Block> GREEN_SCALE_BLOCK = scaleBlock("green_scale_block", MapColor.COLOR_LIGHT_GREEN);
    public static final RegistryObject<Block> BLUE_SCALE_BLOCK = scaleBlock("blue_scale_block", MapColor.COLOR_LIGHT_BLUE);
    public static final RegistryObject<Block> RED_SCALE_BLOCK = scaleBlock("red_scale_block", MapColor.COLOR_RED);

    public static final RegistryObject<Block> FIRE_EGG = egg("fire_dragon_egg", 0);
    public static final RegistryObject<Block> ICE_EGG = egg("ice_dragon_egg", 1);
    public static final RegistryObject<Block> STORM_EGG = egg("storm_dragon_egg", 2);
    public static final RegistryObject<Block> WATER_EGG = egg("water_dragon_egg", 3);

    /** Corazon del Arbol de la Vida: indestructible y luminoso. */
    public static final RegistryObject<Block> LIFE_TREE_HEART = BLOCKS.register("life_tree_heart",
            () -> new LifeTreeHeartBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.EMERALD)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> 15)
                    .pushReaction(PushReaction.BLOCK)));

    /** Hojas doradas del Gran Arbol del Mundo (las que tienen fruto sueltan manzanas doradas y objetos). */
    public static final RegistryObject<Block> WORLD_TREE_LEAVES = BLOCKS.register("world_tree_leaves",
            () -> new WorldTreeLeavesBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(0.2F)
                    .randomTicks()
                    .sound(SoundType.AZALEA_LEAVES)
                    .noOcclusion()
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false)
                    .lightLevel(state -> state.getValue(WorldTreeLeavesBlock.FRUIT) ? 11 : 0)));

    private ModBlocks() {}

    private static RegistryObject<Block> egg(String name, int type) {
        return BLOCKS.register(name, () -> new AncientEggBlock(BlockBehaviour.Properties.of()
                .mapColor(type == 0 ? MapColor.COLOR_RED : (type == 1 ? MapColor.ICE : (type == 3 ? MapColor.WATER : MapColor.COLOR_PURPLE)))
                .strength(1.5F, 6.0F)
                .sound(SoundType.METAL)
                .noOcclusion()
                .lightLevel(state -> 7), type));
    }

    /** Bloque del huevo antiguo segun el tipo (0 fuego, 1 hielo, 2 tormenta). */
    public static Block egg(int type) {
        switch (type) {
            case 1:
                return ICE_EGG.get();
            case 2:
                return STORM_EGG.get();
            case 3:
                return WATER_EGG.get();
            default:
                return FIRE_EGG.get();
        }
    }

    /** Bloque decorativo de escamas: brilla suavemente. */
    private static RegistryObject<Block> scaleBlock(String name, MapColor color) {
        return BLOCKS.register(name, () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(1.5F, 6.0F)
                .sound(SoundType.AMETHYST)
                .lightLevel(state -> 6)));
    }
}
