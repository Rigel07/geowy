package com.isladragoncitos.command;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.entity.species.DragonSpecies;
import com.isladragoncitos.item.DraconicManuscriptItem;
import com.isladragoncitos.system.DraconicData;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Comandos extra de /dragon: habilidades draconianas, especies y trucos para operadores o creativo.
 * (Brigadier fusiona estos subcomandos con los de DragonCommand.)
 */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class DragonExtraCommands {
    private DragonExtraCommands() {}

    private static boolean cheats(CommandSourceStack source) {
        return source.hasPermission(2) || (source.getEntity() instanceof ServerPlayer player && player.getAbilities().instabuild);
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dragon")
                .then(Commands.literal("habilidades").executes(c -> listAbilities(c.getSource())))
                .then(Commands.literal("habilidad").then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(DraconicAbilities.ids(), b))
                        .executes(c -> select(c.getSource(), StringArgumentType.getString(c, "id")))))
                .then(Commands.literal("puntos").requires(DragonExtraCommands::cheats)
                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(-100000, 100000))
                                .executes(c -> points(c.getSource(), IntegerArgumentType.getInteger(c, "cantidad")))))
                .then(Commands.literal("aprender").requires(DragonExtraCommands::cheats)
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(DraconicAbilities.ids(), b))
                                .executes(c -> learnFree(c.getSource(), StringArgumentType.getString(c, "id")))))
                .then(Commands.literal("manuscrito").requires(DragonExtraCommands::cheats)
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(DraconicAbilities.ids(), b))
                                .executes(c -> manuscript(c.getSource(), StringArgumentType.getString(c, "id")))))
                .then(Commands.literal("especie").requires(DragonExtraCommands::cheats)
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(DragonSpecies.ALL_SPECIES.keySet(), b))
                                .executes(c -> species(c.getSource(), StringArgumentType.getString(c, "id"))))));
    }

    private static int listAbilities(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        StringBuilder text = new StringBuilder("\u00a76Habilidades draconianas \u00a77(R lanza, V cambia)\n");
        String selected = DraconicData.getSelectedAbility(player);
        for (DraconicAbilities.Ability ability : DraconicAbilities.all()) {
            boolean known = DraconicData.hasAbility(player, ability.id);
            text.append(known ? "\u00a7a\u2714 " : "\u00a78\u2022 ")
                    .append(ability.id.equals(selected) ? "\u00a7e\u00a7l" : (known ? "\u00a7f" : "\u00a77"))
                    .append(ability.nameEs)
                    .append(" \u00a78(").append(ability.costPoints).append(" pts, ").append(ability.cooldownSec).append(" s)\n");
        }
        source.sendSystemMessage(Component.literal(text.toString()));
        return 1;
    }

    private static int select(CommandSourceStack source, String id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!DraconicData.hasAbility(player, id)) {
            source.sendFailure(Component.literal("No conoces esa habilidad."));
            return 0;
        }
        DraconicData.selectAbility(player, id);
        source.sendSystemMessage(Component.literal("\u00a76Habilidad seleccionada: \u00a7f" + DraconicAbilities.get(id).nameEs));
        return 1;
    }

    private static int points(CommandSourceStack source, int amount) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        DraconicData.addHalfPoints(player, amount * 2);
        source.sendSystemMessage(Component.literal("\u00a7aPuntos draconianos: " + DraconicData.formatPoints(DraconicData.getHalfPoints(player))));
        return 1;
    }

    private static int learnFree(CommandSourceStack source, String id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!DraconicAbilities.exists(id)) {
            source.sendFailure(Component.literal("Esa habilidad no existe."));
            return 0;
        }
        DraconicData.unlockAbility(player, id);
        source.sendSystemMessage(Component.literal("\u00a7aAprendida: " + DraconicAbilities.get(id).nameEs));
        return 1;
    }

    private static int manuscript(CommandSourceStack source, String id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!DraconicAbilities.exists(id)) {
            source.sendFailure(Component.literal("Esa habilidad no existe."));
            return 0;
        }
        player.getInventory().add(DraconicManuscriptItem.of(id));
        return 1;
    }

    private static int species(CommandSourceStack source, String id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        DragonSpecies.SpeciesData data = DragonSpecies.get(id);
        AncientDragonEntity dragon = DraconicData.findDragon(player);
        if (data == null) {
            source.sendFailure(Component.literal("Esa especie no existe."));
            return 0;
        }
        if (dragon == null) {
            source.sendFailure(Component.literal("No encuentro a tu dragon."));
            return 0;
        }
        dragon.setDragonType(data.element.baseType);
        dragon.setSpeciesId(id);
        dragon.setHealth(dragon.getMaxHealth());
        DraconicData.discoverSpecies(player, id);
        source.sendSystemMessage(Component.literal("\u00a76Tu dragon ahora es: \u00a7f" + data.name + " \u00a77(" + data.element.nameEs + ", " + data.rarity.nameEs + ")"));
        return 1;
    }
}
